# Livrable — groupe-michael-rousseau

Modèle de base : `Qwen/Qwen3-0.6B` (révision `c1899de289a04d12100db370d81485cdf75e47ca`)
Adaptateur LoRA : `adaptateur/` (2.3 Mo, float16)
Run MLflow : `lora 300 pas` (67018e44788340fdb3d7538b7de127c9)

| mesure | validation | test |
|---|---|---|
| intent_acc (LoRA) | 100% | 92% |
| exact (LoRA) | 100% | 88% |
| intent_acc (base+prompt) | — | 0% |

Porte de qualité : PASS
Lectures du test pendant le projet : 1
Notes du groupe : donnees/NOTES.md

Pour évaluer ce livrable (le modèle de base est téléchargé automatiquement) :

    uv run python evaluer_livrable.py livrable_groupe-michael-rousseau.zip
    uv run python evaluer_livrable.py livrable_groupe-michael-rousseau.zip --demo
